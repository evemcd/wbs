"use strict";

//+++++++++++++++++++++++++++++++++++++++++++
//####################################################
//img erstellen
function imgCreate(src, title) {
	let figure = document.createElement("figure");
	let figCap = document.createElement("figcaption");
  let img = document.createElement("img");
  //let imgSrc = document.createAttribute("src");
	//let imgAlt = document.createAttribute("alt");
  //let imgTitle = document.createAttribute("title"); 
	img.setAttribute('src', src);
	//img.setAttribute('alt', alt);
	img.setAttribute('alt', title);
	img.setAttribute('title', title);

	figCap.appendChild(document.createTextNode(title));
	
  figure.classList = "slides left";
	figCap.style="color: #fff; text-align: center; padding: 5px;";
	img.classList = "img-fluid";
	figure.appendChild(img);
	figure.appendChild(figCap);
  return figure;
}


let request = new XMLHttpRequest();
request.addEventListener("load", () => {
  if(request.status === 200) {
   console.log("Datei  gefunden");
	 let  json = request.response;
	 let  bilder = json.bilder;
	 for(let element of bilder) {
		 let img = imgCreate(element.bild,element.titel);
		 //console.log(element.bild);
		document.getElementById("slider").appendChild(img);
	 }
	 slider();
  }
	else if(request.status === 404) {
		console.log("Datei nicht gefunden");
  }
 
});

request.open("GET","bilder.json",true);
request.responseType = "json";
request.setRequestHeader("Accept", "application/json");
request.send();	
//####################################################
let counter = 0;
let slider = function(){
	let bilder = document.querySelectorAll(".slides");
	for(let element of bilder) {
		element.setAttribute("style","display: none;");
		console.log(element);
	}
	
	if(counter === bilder.length) counter=0;
	bilder[counter].setAttribute("style","display: block;");
	counter++;
	setTimeout(slider, 5000);
}
//####################################################




