"use strict";

const helpElements = document.querySelectorAll('[data-help]')

for(const helpElement of helpElements){
        helpElement.addEventListener('mouseover', (event) => {
            //alert('helpElement wurde angeklickt')
            alert(helpElement.attributes['data-help'].value)

            //sonst sprint immer nach oben weil href="#"
            event.preventDefault()
        })
    }


const cardElements = document.getElementsByClassName('card')
 for(const cardElement of cardElements) {

        cardElement.addEventListener('click', (event) => {
            console.log(cardElement.classList.toggle('show'))
        })
       
}
    












