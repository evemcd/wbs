"use strict";

/*
for ... of
for ... in  

ausgabe += "In Liste1 in Position " + i + " steht der Teilnehmer" + name;
oder
ausgabe += `In Liste1 in Position. ${i+1} steht der Teilnehmer ${name}`;

forEach ist einfacher, wenn wir das Array vollständig durchlaufen wollen
Die Funktion erwartet als Parameter eine weitere Funktion
Solche Funktionen werden Iteratorfunktionen genannt

array.forEach(function callback(currentValue [, index [, array]])
callback
    Funktion, die auf jedes Element angewendet wird mit drei Argumenten:

currentValue
        Der Wert des aktuellen Elements im Array.
index Optional
        Der Index des aktuellen Elements im Array.
array Optional
        Das Array, welches mit forEach() durlaufen wird.
*/
function modulo(wert) {
  //console.log(wert + ' % 2 = ' + wert % 2);
  let ausgabe = '';
  ausgabe = wert + ' % 2 = ' + wert % 2 + '<br />';
  document.getElementById('box1').innerHTML += ausgabe;
}

/*
modulo(20);

modulo(21);
*/
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//eine Funktion (Prozess) für jedes Element vom Array ausführen
let liste1 = [2, 3, 4, 5, 6, 7, 22, 35, 56];
liste1.forEach(modulo);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
let liste2 = ['Max','Tom','Jerry','Angela','Helene','Boss','Mann'];
/*
function print(name, i) {
  let ausgabe = ``;
  ausgabe = `In Position ${i+1} steht der Teilnehmer <strong>${name}</strong> <br />`;
  document.getElementById('box2').innerHTML += ausgabe;
}

liste2.forEach(print);
*/

liste2.forEach( (name, i) => {
  let ausgabe = ``;
  ausgabe = `In Position ${i+1} steht der Teilnehmer <strong>${name}</strong> <br />`;
  document.getElementById('box2').innerHTML += ausgabe;
} );
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Funktionen über Kurzschreibweise definieren
//const summe = function(wert1, wert2) { return wert1 + wert2; }
// oben und unten das Gleiche
//über Arrow functions "=>" viel einfacher und Platzsparender
//const summe = (wert1, wert2) => { return wert1 + wert2; }

//bei einer Anweisung kann man {} auch weglassen
//dann auf return verzichten da das Ergebnis wert1 + wert2 automatisch zurückgegeben wird.

const summe = (wert1, wert2) => wert1 + wert2;

console.log( summe(12,4) );
console.log( summe(5,33) );

//bei Funktionen mit 1 Parameter, kann () weggelassen werden
const showInfo = message =>  console.log(message);

showInfo('Hallo');
showInfo('JS ist sehr einfach');

//Bei Funktionen ohne Parameter, wird ein leeres () verwendet
const druck = () => console.log('Hello World');

druck();
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Werte aus einem Array extrahieren
let liste3 = ['Grass','Kästner','Ringelnatz','Rilke','Grillparzer','Heine'];

let eins = liste3[0];
let zwei = liste3[1];
let drei = liste3[2];
let vier = liste3[3];
let fuenf = liste3[4];
let sechs = liste3[5];

console.log(eins);
console.log(fuenf);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Werte aus einem Array extrahieren (mit Destructuring)
console.log('+'.repeat(20) );

/*
let [one, two, three, four, five, six] = liste3;

console.log(one);
console.log(two);
*/

//let liste3 = ['Grass','Kästner','Ringelnatz','Rilke','Grillparzer','Heine'];

//Nur bestimmte Werte extrahieren
/*
let [one,,three] = liste3;

console.log(one);
console.log(three);
*/

//let liste3 = ['Grass','Kästner','Ringelnatz','Rilke','Grillparzer','Heine'];
let [one,,three, ...rest] = liste3;

console.log(one);
console.log(three);
console.log(rest);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Primitive Datentypen und Referenztypen
/*
Genau gesagt gibt es sieben Grundtypen in JavaScript:

    Undefined
    Null
    Boolean
    String
    Symbol
    Number
    Object

Mit den ersten sieben Typen lassen sich sogenannte einfache Werte (englisch primitive values) erzeugen. Ein einfacher Wert ist das Gegenteil eines komplexen Wertes. Er lässt sich nicht weiter auspacken und zerlegen.

Der siebte Typ, Object, umfasst alle Objekte. Das sind eine ganze Menge, denn es gibt viele Unter-Typen, die vom Typ Object abgeleitet sind. Werte dieser Typen sind komplex. Das heißt, sie sind aus einfachen Werten aufgebaut.

Einfache Werte werden als Kopie an Funktionen übergeben, während Objekte als Referenzen übergeben werden. Eine Referenz ist die Adresse im Speicher, wo das Objekt abgelegt wurde.

Primitive Datentypen:
undefined, null, boolean, number, string, and symbol

Referenztypen:
object
*/
console.log('+'.repeat(20) );

console.log( typeof 'Hallo' );
console.log( typeof 123);
console.log( typeof true );
console.log( typeof [] );
console.log( typeof {} );

console.log('+'.repeat(20) );
let a = 5;
let b = a;

b = 4;
console.log( a + ' ' + b);

console.log('+'.repeat(20) );

let x = {
  firstName : 'Max',
  lastName: 'Mustermann'
}

let y = x;

console.log('x : ' + x.firstName);
console.log('y : ' + y.firstName);

console.log('+'.repeat(20) );

y.firstName = 'Moritz';

console.log('x : ' + x.firstName);
console.log('y : ' + y.firstName);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Alter berechnen
let geboren = new Date(1996, 10, 19);
let geboren_sekunden = geboren.getTime();

let jetzt = new Date();
let jetzt_sekunden = jetzt.getTime();

/*
console.log(geboren_sekunden);
console.log(jetzt_sekunden);
*/
let alter = jetzt_sekunden - geboren_sekunden;

//console.log(alter);

let jahr_in_sek = 365 * 24 * 60 * 60 * 1000;

document.getElementById('box3').innerHTML = 
                        'Klaus ist jetzt um die ' + Math.ceil(alter/jahr_in_sek) +'j. alt.';
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*
setInterval() - führt eine Funktion in bestimmten Zeitabständen aus

setInterval( function(){ alert('Hallo'); } , 1000 );

setTimeout() - führt eine Funktion nach einem bestimmten Zeitraum aus.
setTimeout( function(){ alert('Hallo'); } , 1000 );


function zeigeInfo() {
  alert('Wir sind im Auftrag des Herrn unterwegs');
  console.log('Hallo Welt');
}

setTimeout(zeigeInfo, 2000);


let uhr = () => {
  let jetzt = new Date();
  document.getElementById('box4').innerHTML = jetzt.getHours() + ':' +
                                              jetzt.getMinutes() + ':' +
                                              jetzt.getSeconds();
}

//uhr();
setInterval(uhr(), 1000);
*/

let uhr = () => {
  let jetzt = new Date();
  //++++++++++++++++++++
  let std = jetzt.getHours();
  let min = jetzt.getMinutes();
  let sek = jetzt.getSeconds();
  //++++++++++++++++++++
  if(std < 10) {
    std = '0' + std;
  }
  if(min < 10) {
    min = '0' + min;
  }
  if(sek < 10) {
    sek = '0' + sek;
  }
  //+++++++++++++++++++++
  document.getElementById('box4').innerHTML = std + ':' + min + ':' + sek;

  setTimeout(uhr, 1000);
}

uhr();
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
let liste4 = ['Max','Tom','Jerry','Angela','Helene','Boss'];

console.log(liste4);
console.log('+'.repeat(20));
console.log(liste4.reverse() );
console.log('+'.repeat(20));
console.log(liste4.sort() );
console.log('+'.repeat(20));
console.log(liste4);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
let liste5 = [5,1,-1,-3,0,2,12,10];

console.log(liste5);
console.log(liste5.sort() );
document.getElementById('box5').innerHTML = liste5;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*
-1 => wenn das erste Element vor dem 2 stehen soll
1 => wenn das zweite Element vor dem 1 stehen soll
0 => wenn beide Elemente gleich sind
*/
function vergleich(a, b) {
  if(a > b) {
      return 1;
  }
  else if(b > a) {
      return -1;
  }else {
    return 0;
  }
}
document.getElementById('box6').innerHTML = liste5.sort(vergleich);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
let zahlen = [1,2,-1,-3,0,12,10];

function sortierung(a, b) {
  //aufsteigend
  //return a - b;

  //absteigend
  return b - a;
}
//um Nummern anstatt Strings zu vergleichen
//einfach b von a subtrahieren
//sort-Methode kann mit FunktionsAusdrücken benutzt werden
document.getElementById('box7').innerHTML = zahlen.sort(sortierung);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++