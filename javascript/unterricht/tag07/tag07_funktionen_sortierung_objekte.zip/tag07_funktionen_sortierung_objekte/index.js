"use strict";

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*
Wenn a und b zwei zu vergleichende Elemente sind, gilt Folgendes:

Ist compareFunction(a, b) größer als 0, sortiere b auf einen niedrigeren Index als a, 
d. h. b kommt zuerst.

Ist compareFunction(a, b) kleiner als 0, sortiere a auf einen niedrigeren Index als b, 
d. h. a kommt zuerst.

Ist compareFunction(a, b) gleich 0, bleibt die Reihenfolge von a und b in Bezug zueinander unverändert, werden aber im Vergleich zu den restlichen Elementen des Arrays einsortiert. 
    
compareFunction(a, b) muss immer denselben Wert zurückgeben, wenn dasselbe Paar an Argumenten a und b übergeben wird. Werden inkonsistente Ergebnisse zurückgegeben, ist die Sortierreihenfolge undefiniert.

*/
function vergleich1(a, b) {
  if(a > b) {
    return 1;
  } else if(a < b) {
    return -1;
  } else {
    return 0;
  }
}

let liste1 = [5,1,-1,-3,0,2,12,10];
liste1.sort(vergleich1);
document.getElementById('box1').innerHTML = liste1;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
function vergleich2(a,b) {
  return a-b;
}

let liste2 = [5,0,12,23,1,10,-3,-10];

liste2.sort(vergleich2);

document.getElementById('box2').innerHTML = liste2;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
function vergleich3(a, b) {
  //return a.toLowerCase().localeCompare(b.toLowerCase());
  return a.localeCompare(b, 'de-DE');
}

let liste3 = ['gelbe Farbe','gelb','Dunkel Grau','Grau','blau','Black','Ähnlich'];

liste3.sort(vergleich3);
document.getElementById('box3').innerHTML = liste3;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
function vergleich4(a, b) {
  /*
  if(a.length > b.length) {
    return 1;
  }else if(a.length < b.length) {
    return -1;
  }else {
    return 0;
  }
  */

  let erg = (a.length > b.length) ? 1 : (a.length < b.length) ? -1 : 0;
  return erg;
}
let liste4 = ['Schenkendorf', 'Kästner', 'Ringelnatz','Rilke','Grillparzer','Schiller'];

liste4.sort(vergleich4);

document.getElementById('box4').innerHTML = liste4;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Mehrdimensionale Array (Arrays von Arrays)
let liste5 = [
  ['Deutschland','Berlin',82],
  ['Niederlande','Amsterdam',17],
  ['Frankreich','Paris',67],
  ['Burkina Faso','Ouagadougou',21],
  ['Oman','Maskat',5]
];

console.log(liste5);
console.log(liste5.length);
console.log(liste5[0]);
console.log(liste5[0].length);
console.log(liste5[0][0]);
console.log(liste5[4][1]);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Alle Daten in einer Liste ausgeben
let ausgabe1 = '';
for(let wert of liste5) {
  ausgabe1 += '<ul>';
  ausgabe1 += '<li>'+wert+'</li>';
  ausgabe1 += '</ul>';
}

document.getElementById('box5').innerHTML = ausgabe1;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
let ausgabe2 = '';
for(let wert of liste5) {
  ausgabe2 += '<ul class="list-group my-2">';
  ausgabe2 += '<li class="list-group-item list-group-item-info">'+wert[0]+'</li>';
  ausgabe2 += '<li class="list-group-item list-group-item-light">'+wert[1]+'</li>';
  ausgabe2 += '<li class="list-group-item list-group-item-secondary">'+wert[2]+'</li>';
  ausgabe2 += '</ul>';
}

document.getElementById('box6').innerHTML = ausgabe2;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
function vergleich5(a, b) {
  return a[0].localeCompare(b[0], 'de-DE');
}

liste5.sort(vergleich5);

let ausgabe3 = '';
for(let wert of liste5) {
  ausgabe3 += '<ul class="list-group my-2">';
  ausgabe3 += '<li class="list-group-item list-group-item-warning">'+wert[0]+'</li>';
  ausgabe3 += '<li class="list-group-item list-group-item-success">'+wert[1]+'</li>';
  ausgabe3 += '<li class="list-group-item list-group-item-primary">'+wert[2]+'</li>';
  ausgabe3 += '</ul>';
}

document.getElementById('box7').innerHTML = ausgabe3;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*
Es gibt eine elegantere Lösung, wie man Daten erstellt, die
zusammengehören
Objekte

{ schlüssel : wert}

const schueler = {
  "name"    : 'Max Müller',
  "alter"   : 22,
  "sprache" : 'Englisch'
}
*/

//eine andere Möglichkeit, Objekte zu erstellen
const schueler = {
  name    : 'Moritz Müller',
  alter   : 22,
  sprache : 'Englisch'
}
console.log(schueler);

console.log('*'.repeat(40));

//auf die Eigenschaften zugreifen
console.log(schueler.name);

console.log('*'.repeat(40));
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//andere Möglichkeit, wie man auf die Eigenschaften zugreifen kann
console.log("Er spricht nur " + schueler["sprache"]);

console.log(schueler.alter + "j. alt");

console.log('*'.repeat(40));

//man kann auf die Eigenschaften auch schreibend zugreifen
//schueler["alter"] = 24;

//andere Schreibweise
schueler.alter = 24;
console.log(schueler.name + " ist " + schueler.alter +"j alt");
console.log('*'.repeat(40));
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//neue Eigenschaft hinzufügen
schueler.wohnort = "München";
schueler["interesse"] = "Angeln";

console.log(schueler);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Eine Eigenschaft löschen
//die Eigenschaft ist da, nur der Wert wird gelöscht
//schueler.alter = null;

//wenn man alles löschen möchte dann:
//delete schueler.alter
delete schueler['alter'];

console.log(schueler);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Unterschied zwischen verschiedenen Schreibweisen
//bestimmte Zeichen bzw. Schreibweisen sind nicht erlaubt
const daten = {
  "name"  : "Angela Merkel",
  alter   : 23,
  "2019-2020" : "jQuery, JS",
  "gewünschter kurs"  : "JSON"
}

console.log('*'.repeat(40));
console.log(daten);
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
console.log('*'.repeat(40));

//Unterschied  - bei . Schreibweise
console.log(daten.name);

//die untere Schreibweise ist flexibler
console.log(daten["name"]);
console.log(daten["na" + "me"]);

console.log('*'.repeat(40));

//console.log(daten."2019-2020");
//console.log(daten."name")
//so wie oben mit . kann man unten nicht schreiben
console.log(daten["2019-2020"]);

let a = "name";

console.log('*'.repeat(40));
//console.log(daten.a);
console.log(daten[a]);

console.log(daten["gewünschter kurs"]);
//geht nicht, weil Leerzeichen drin
//console.log(daten.gewünschter kurs)

//geht nicht: nach . ohne '' schreiben
//console.log(daten.'gewünschter kurs')
//console.log(daten.'name')
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
const daten2 = {
  name    :   "Angela Merkel",
  alter   :   23,
  angemeldet  : false,
  kursNummer  : 0,
  //ort         : "Berlin"
}

//hier wird gekuckt, ob die Eigenschaften da ist
//und ob die einen Wert hat?
if(daten2.angemeldet) {
  console.log("Hallo, Du bist online");
} else {
  console.log("Du bist offline");
}

//wenn eine Eigenschaft nicht da ist, wird undefined angezeigt
console.log(daten.wohnort);

console.log("*".repeat(40));

//hier wird gekuckt
//ob die Eigenschaft da ist (ob Wert oder nicht egal)
if("ort" in daten2) {
  console.log("IF in : Du hast einen Wohnort");
} else {
  console.log("IF in : Du hast keinen Wohnort");
}

//hier wird angezeigt, weil kursNummern da ist
if("kursNummer" in daten2) {
  console.log("IF in : Kurs");
} else {
  console.log("IF in : kein Kurs");
}

console.log("*".repeat(40));

/*
kursNummern hat den Wert 0
0 wird in false umgewandelt
also...hat keinen Wert
*/
if(daten.kursNummer) {
  console.log("IF: KursNummer");
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
console.log('*'.repeat(40));
//Nur Schlüssel ausgeben
//Object => O => Großbuchstabe

console.log(Object.keys(daten2) );
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
console.log('*'.repeat(40));
//Nur die Werte ausgeben

console.log(Object.values(daten2) );
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Objekte in array rein tun
let students = [
  {name:  "Merkel", vorname:  "Angela"},
  {name:  "Fischer", vorname:  "Helene"},
  {name:  "Bohlen", vorname:  "Dieter"},
];

console.log('*'.repeat(40));

console.log("Studenten: " + students);
console.log("Studenten: " + students[0]);
console.log("Studenten: " + students[0]["name"]);
console.log("Studenten: " + students[1]["name"]);
console.log("Studenten: " + students[2]["name"]);

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//in Objekte array rein tun
const obj = {
  name: 'Merkel',
  urlaub: ['Paris','Dubai','Hamburg']
}

console.log(obj);
console.log('*'.repeat(40));
console.log(obj['urlaub']);
console.log(obj['urlaub'][0]);
console.log(obj['urlaub'][2]);
