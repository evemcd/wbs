"use strict";

//####################################################
//die Funktionen erst ausführen, wenn DOM geladen ist
jQuery(document).ready(function() {

  //jQuery("p").css("color","#cd0000");
  $("p").css("color","#cd0000");

  //let absatz = $("p.absatz");
  //$(absatz).css("background-color","#999")

  //$("p.absatz").css("background-color","#000").css("color","#fff");

   //ohne jQuery musste man so schreiben
  /*
  let absatz = document.querySelectorAll("p.absatz");
  for(let element of absatz) {
    element.style.color = "#000";
    element.style.backgroundColor = "#fff";
  }
  */

  $("#absatz").css("font-size","3rem");

  //$("li:eq(3)").css("background-color","#dc3545");

  //$("ul li:not(li:eq(2))").css("background-color","#dc3545");

  //$("p:not(.absatz, #absatz)").css("background-color","#dc3545");

  $("th, td").css("color", "#999");
//##################################################
//Event
//Auf Ereignisse reagieren
/*
	ohne jQuery musste man so schreiben:
	document.getElementById("idWert").addEventListener("click",function(){});
	
	mit jQuery
	$("#id").click(function(){});
*/
  /*
  $("#absatz").click(function() {
    $("#absatz").css("color","#0f0");
  });

  //hier werden alle Absätze gefärbt, egal auf welchen Absatz geklickt wird
  $("p").click(function() {
    $("p").css("color","#0f0");
  });

  //this => wird der angeklickte Absatz angesprochen
  $("p.absatz").click(function() {
    $(this).css("color","#0f0");
  });
  */

  $("p").mouseenter(function() {
    $(this).css("color","#0f0");
  });

  $("p").mouseout(function() {
    $(this).css("color","#cd0000");
  });
  //########################################################
  $("#btn1").click(function(){
    $("#auftrag").addClass("anders");
  });

  $("#btn2").click(function(){
    $("#auftrag").removeClass("anders");
  });

  $("#btn3").click(function(){
    $("#auftrag").fadeOut(2000);
  });

  $("#btn4").click(function(){
    $("#auftrag").fadeIn(500);
  });

  $("#btn5").click(function(){
    $("#auftrag").hide(3000);
  });

  $("#btn6").click(function(){
    $("#auftrag").show(300);
  });

  $("#btn7").click(function(){
    $("#auftrag").fadeToggle(1000);
  });

  $("#btn8").click(function(){
    $("#auftrag").toggleClass("anders");
  });
//#############################################
/*
<ul>
  <li><a href="">Link</a></li>
  <li>
    <a href="">Link</a>
    <ul>
       <li><a href="">UnterMenue</a></li>
    </ul>
  </li>
</ul>
*/
$("ul li:has(ul)")
  .find("a:first")
    .css(
          {
            "color":"#f00",
            "font-size":"1.3rem"
          }
        );

}); //ende ready

//#############################################
//wichtige Methoden
/*
		setzt eine CSS-Eigenschaft für ein Element
		.css("color","red")
		
		lese eine CSS-Eigenschaft aus
		.css("color")
		
		console.log($("p").css("color"));
		
		Füge eine CSS-Klasse hinzu
		.addClass("bunt")
		
		Entferne eine CSS-Klasse 
		.removeClass("bunt")
		
		.attr("data-help")
		.attr("data-help","Kurse") 
		
		console.log($("p").attr("data-help","Kurse"))
		console.log($("p").attr("data-help"))
*/

/*
Problem:
Es gibt Unterschiede zwischen den Browsern
Beispiel:
document.querySelector()
Nicht alle Browser untersützen alle Features
das war einer der Hauptgründe, warum Frameworks entstanden sind.
Mootools, jQuery (das popolärste  Framework)
-------------------------------------------
Izwischen, wenn wir code schreiben, der in modernen Browsern funktioniert, ist das nicht der Grund jQuery ect. zu verwenden sondern, weil unser code massiv vereinfacht wird.
------------------------------------------
Lösung:
Wir schieben eine Ebene dazwischen
Diese Ebene kümmert sich darum, dass alles in allen Browsern gleich funktioniert.
-Einfacheres Arbeiten mit dem DOM
-Einfacheres Arbeiten mit Events.
-Einfacheres Formulieren von Ajax-Anfragen
-----------------------------------------
jQuery -> gibt es seit 2006
-----------------------------------------
Das Kernstück von jQuery bildet die Funktion jQuery() bzw. die gleichbedeutende Shortcut-Funktion $().

let selektor = $("#selektor");

$(selektor).css("color","green");
$("#selektor").css("color","green");
-----------------------------------------
um jQuery zu benutzen, sollte man erstmal jQuery runterladen
jquery.com
dann auf download (die nicht komprimierte)

bei slim  sind die Ajax Sachen nicht drin
-----------------------------------------
jquery-Datei einbinden (Reihenfolge ist wichtig)
*/
