"use strict";

/*
console.log("Hallo Welt");
console.log("Hallo JavaScript");

JS führt alles von oben nach unten aus

auch ohne ; kann JS die Befehle erkennen
weil ein Zeilenumbruch dort steht

NUR, wenn alles in einer Zeile steht dann ; wichtig

wegen der Sauberkeit lieber mit ; schreiben

auch egal, ob ein Leerzeichen oder Tab dort steht

console.log("Hallo Welt")
console.log("Hallo JavaScript")

//unten muss ; geschrieben werden
console.log("Hallo Welt"); console.log("Hallo JavaScript");
*/

//++++++++++++++++++++++++++++++++++++++++++++++++++
/*
console.log("Hallo Welt!");
console.log("Hallo Welt!");
console.log("Hallo Welt!");
console.log("Hallo Welt!");
*/

//Variablen
/*
//auch ohne let kann man eine Variable definieren
//JS ist für Webbrowser erstellt und langsam gewachsen

//Überbleibsel von früher (Variable ohne let oder var erstellen)
//damit auch das, was früher war immernoch funktioniert
//das verursacht aber sehr viele Bugs

//deswegen "use strict" ganz oben schreiben
//damit sagen wir, das alte JS sollte nicht hier gelten
//Programme, die "use strict" nicht verstehen, ignorieren den Hinweis

let gruss = "Hallo Welt, wie geht es dir?";
console.log(gruss);
console.log(gruss);
console.log(gruss);
console.log(gruss);

let a = 22;
let a = "Hallo";
*/
//++++++++++++++++++++++++++++++++++++++++++++++++++
//Datentypen in JS
//Datentypen beeinflüssen das verhalten von JS
//String entweder mit '' oder ""
//aber einheitlich schreiben mit '' oder ""
/*
let a = 'Hallo Welt';
console.log(a);
//Datentyp rausfinden
console.log(typeof a);

//Zahlen
//kommazahl wird über . definiert (4.5)
let b = 42;
console.log(b);
console.log(typeof b);

//Boolean (true / false)
let c = true;
console.log(c);
console.log(typeof c);
*/
//++++++++++++++++++++++++++++++++++++++++++++++++++
//Das Plus-Zeichen
//wird für mathematische Berechnungen benutzt und für Verkettung
/*
console.log(5 + 6);
console.log("Hallo " + "WebDev");
console.log("10" + "1.9");
console.log(10 + "1.9");
*/
//++++++++++++++++++++++++++++++++++++++++++++++++++
//wichtige String-Funktionen

let greeting = '   +++Hallo Welt!+++   ';

//die Anzahl der Zeichen in einem String
console.log(greeting.length);
// 0 1 2 3 4 PC
// H a l l o
// 1 2 3 4 5 Menschen

//Ein einzelnes Zeichen ausgeben
console.log( greeting.charAt(6) );
console.log(greeting[6]);

//Wo befindet sich ein Zeichen in einem String(Position)?
console.log(greeting.indexOf("H") );

//indexOf() findet das 1. vorkommen eines Zeichens
console.log(greeting.indexOf("+++") );

//such nach "+++" aber erst nach Position 5 und bis zum Ende
console.log(greeting.indexOf("+++", 5) );

//Großbuchstaben und Kleinbuchstaben
console.log(greeting.toUpperCase() );
console.log(greeting.toLowerCase() );

//Text ersetzen
console.log(greeting.replace("!","!!"));

//Leerzeichen entfernen
console.log(greeting );
console.log(greeting.length );
console.log(greeting.trim() );
//der ursprgl. Wert der Variable ändert sich nie
//es wird immer eine Kopie der Variable erstellt
//wenn man die urspgl. Variable verändern möchte dann
//greeting = greeting.toUpperCase();
//greeting = greeting.trim();
//console.log(greeting)

//man kann auch viele Funktionen anwenden und hintereinander schreiben
console.log(greeting.trim().length );

//NewLine -> Zeilenumbruch
console.log("Hallo \nWelt");

//Zeilenumbruch wird als ein Zeichen interpretiert
console.log(typeof "\n");

// wenn man \ anzeigen möchte
console.log("Hallo \\ Welt");

//String wiederholen
console.log("-".repeat(30) );

//slice(start, ende)
console.log("Hallo JavaScript".slice(0,4) );

//substr(start, length)
//fang bei Position 6 an und zeig 2 Zeichen
console.log("Hallo JavaScript".substr(6,2) );

//fang bei Position 6 an und zeig alles bis zum Ende
console.log("Hallo JavaScript".substr(6) );