"use strict";

jQuery(document).ready(function() {
/*
den Wert vom Attribut anzeigen
.attr("nameDesAttributes") 

Einen neuen Wert in ein Attribut rein tun
.attr("nameDesAttributes", "neuerWertFürDasAttribut") 
*/
  $("#bild1").mouseover(function() {
    //auf den Wert von src zugreifen
    //alert( $(this).attr("src") );
    $(this).attr("src","../images/big/bild-01.jpg")
  });


  $("#bild1").mouseout(function() {
    $(this).attr("src","../images/small/bild-01.jpg")
  });

  //########################################################
  $("h2").next("p").css({
    "background-color"  : "#efefef",
    "color"             : "#333",
    "padding"           : "10px"
  });

  //########################################################
  $("a[href^=http]").css({
    "background-color"  : "#cd0000",
    "color"             : "#fff",
    "padding"           : "5px 10px",
    "display"           : "inline-block",
    "text-decoration"   : "none"
  });

  $("a:contains(Mehr Info hier)").css({
    "background-color"  : "#333",
    "color"             : "#fff",
    "padding"           : "5px 10px",
    "display"           : "inline-block",
    "text-decoration"   : "none"
  });
 //########################################################
 $("#liste").click(function(){
  //document.createElement("li");
   let li = jQuery.parseHTML("<li>Mango</li>")

  //wichtige Methoden
  /*
		.append(element)
			Füge das Element am Ende des aktuellen Elementes in die DOM ein.
			
		.prepend(element)
			Füge das Element am Anfang des aktuellen Elementes in die DOM ein.
			
		.before(element)
			Füge das Element vor das aktuelle Element ein.
			
		.after(element)
			Füge das Element nach dem aktuellen Element ein.
			
		.remove()
			Entfernt das aktuelle Element aus der DOM
  */

  //$(this).append(li);
  //$(this).prepend(li);
  //$(this).before(li);
  //$(this).after(li);
   $(this).remove();
 });
 //########################################################
$(".gallery-item").click(function (event) {
  event.preventDefault();
  //let overlay = jQuery.parseHTML("<div id='overlay'></div>");
  let overlay = $.parseHTML("<div id='overlay'></div>");
  //packe das div am Ende der Datei
  $("body").append(overlay);
  //auf den Wert von href zugreifen
  let image = $.parseHTML("<img id='overlay-image'></img>");
  //alert(href);
  //den Wert von href in src rein tun
  let href = $(this).attr("href");

  $(image).attr("src",href);

  $(overlay).append(image);
  //---------------------------------------
  //wenn auf Bild geklickt wird dann schliessen
  /*
    $(image).click(function(){
      $("#overlay").remove();
    });
  */

  //wenn man auf den grauen Bereich klickt dann soll alles schliessen
  $("#overlay").click(function(){
    $(this).remove();
  });

});//ende click overlay






});//ende ready