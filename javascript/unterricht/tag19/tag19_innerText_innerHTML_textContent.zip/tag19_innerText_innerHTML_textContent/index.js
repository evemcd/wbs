"use strict";

/*
//letzt Änderung der Datei
console.log(document.lastModified);

//gibt es cookies?
console.log(document.cookie);

//welche Verweise gibt es auf der Seite
console.log(document.links);
console.log(document.images);
console.log(document.URL);
*/
//####################################################
/*textContent -> auf den TextInhalt eines Knotens zugreifen

die Eigenschaft ist sehr praktisch, da man in der Praxis bei Zugriff auf den Textinhalt nicht daran interessiert ist, ob und welche zusätzlichen Auszeichnungen verwendet wurden.

textContent ignoriert Markup innerhalb eines Elements
*/
console.log( document.querySelector('#news li:nth-of-type(1)').textContent );

//innerHTML -> auf den HTML-Inhalt eines Knotens zugreifen
console.log( document.querySelector('#news li:nth-of-type(1)').innerHTML );

/*
Möchten Sie den Textinhalt eines Elements neu setzen, kann man wieder textContent verwenden

Markup (HTML-Elemente hinzufügen -> nicht möglich (über textContent)

textContent verhält sich genauso wie innerText.
innerText geht leider in einigen Browsern nicht
Lieber textContent benutzen
*/
document.querySelector('#news li:nth-of-type(1)').textContent = 'Endlich alles neu.'
console.log( document.querySelector('#news li:nth-of-type(1)').textContent );