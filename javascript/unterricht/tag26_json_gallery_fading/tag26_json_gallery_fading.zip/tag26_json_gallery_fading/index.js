"use strict";


//####################################################
jQuery(document).ready(function(){

  $("#inhalt").click(function(){
    $(this).append("hallo");
  });
  //--------------------------
  $(".box").click(function(){
    $(this).appendTo("#inhalt");
  });
//####################################################
  $("#box1 ul li").first()
                    .css({"font-size":"2rem", "color":"#00bfff"})
                      .end()
                        .css({"font-size":"1rem", "color":"#ff3030"});

  //---------------------------
  $("#box1 p").first()
                .css({border: "3px solid red"})
                  .end()
              .last()
                .css({border: "3px dotted green"})
                  .end()
                .css({"font-weight": "bold"})
//####################################################
//JSON einbinden
/*
$.ajax({
	url: "bilder.json",
	dataType: "json",
	type: "GET"
});

jQuery.Deferred()
Eine Factory-Funktion, die ein verkettebares Dienstprogrammobjekt mit Methoden zurückgibt, um mehrere Rückrufe in Rückrufwarteschlangen zu registrieren, Rückrufwarteschlangen aufzurufen und den Erfolgs- oder Fehlerstatus einer synchronen oder asynchronen Funktion weiterzuleiten.

$.ajax() -> führt eine asynchrone http-Anfrage durch

.done() -> fügt einen Handler hinzu, der aufgerufen werden soll, wenn das Deferred-Objekt aufgelöst wird.
(ausführen wenn die Datei gefunden wird)

.fail() ->
füge einen Handler hinzu, der aufgerufen werden sollen, wenn das zurückgestellte Objekt abgelehnt wird.
(Meldung ausgeben wenn die Datei nicht gefunden wird)

$.get() -> führt eine asynchrone http-Anfrage unter der verwendung  der HTTp-Methode GET durch
*/
let info = "";

$.get({
  url: "bilder.json",
  dataType: "json"
})

.done(function(data){
  //console.log(data);
  let bilder = data.bilder;
  console.log(bilder);

  $.each(bilder, function(i, item){
    info += "<div><img src='"+item.bild+"' alt='"+item.titel+"' /><p>"+item.titel+"</p></div>";
  });

  $("#jsonDaten").html(info);
  //-------------------------
   $("#jsonDaten div").first().fadeIn(3000);

 
  setInterval(function(){
    $("#jsonDaten div").first().fadeOut(2500).next("div").fadeIn(3000).end().appendTo("#jsonDaten");
  }, 5500)


})

.fail(function(){
  console.log("Datei nicht gefunden oder Fehler");
});


//#####################################################
//navigation
/*
  AusgangsLage
  <li>
    <span></span>
    <a href="#">Home</a>
  </li>

  Ziel
  <li>
    <span>Home</span>
    <a href="#">Home</a>
  </li>
*/
$("#navi1 li").prepend("<span></span>");

//alle li einzeln ansprechen
$("#navi1 li").each(function() {
  //finde den HTML-Inhalt vom a-Tag (innerhalb von li)
	//let linkText = $(this).find("a").html(); 

  //finde den Text-Inhalt vom a-Tag
  let linkText = $(this).find("a").text();

  //console.log(linkText);
  //füge den Text von a in den span-Tag ein (in jedem li einzeln)
  $(this).find("span").text(linkText);
});

//stop() ist wichtig.....falls ein User kurz drauf geht und weg, dann wird die Animation nicht bis zum Ende abgespielt
$("#navi1 li").hover(
                    function(){
                      //durch "margin-top":"-40px" geht span nach oben und taucht a-Element auf
                      $(this).find("span").stop().animate({"margin-top":"-40px"},700,"easeOutBounce");
                    },
                    function(){
                      $(this).find("span").stop().animate({"margin-top":"0"},300);
                    }
                    );






});
//ende ready()

/*
Die jQuery-Methode  .end() wird verwendet, um die letzte Filteroperation in der aktuellen Kette zu beenden und dann den übereinstimmenden Satz von Elementen in seinen vorherigen Zustand zurückzusetzen.

Die Methode end() ist nützlich, wenn man jQuery für Verkettungszwecke verwenden.

Diese Methode akzeptiert keine Argumente.
-----------------------------------

appendTo() und preprendTo()

Mit der jQuery-Methode appendTo() kann man beliebige neue Inhalte in Elemente verschachteln. 
Während after() Inhalte hinter ein schließendes Element platziert, kann man dank appendTo() also beliebigen Code innerhalb eines anderen Elementes platzieren. 

 Alternativ kann man auch die Funktion prependTo() nutzen, wenn man die Auswahl nach dem öffnenden Tag setzen möchte.

*/