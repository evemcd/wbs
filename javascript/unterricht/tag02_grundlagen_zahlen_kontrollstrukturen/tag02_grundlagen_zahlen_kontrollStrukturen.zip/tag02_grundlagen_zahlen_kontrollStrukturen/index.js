"use strict";

//Variablen kann man per var auch definieren (früher wurde die Variablen mit var definiert)
//das funktioniert auch heute
//Lieber das vermeiden weil es dort zu problemen kommen kann
var str = "Hallo JS";
str = "Hallo PHP";
console.log(str);

console.log("-".repeat(40) );

let str2 = "Hallo Welt";
str2 = "Hallo HTML";
console.log(str2);

//+++++++++++++++++++++++++++++++++++++++++++

var a = 2;
a = 55;
// sehr viele Zeilen
var a = 6;
console.log(a);
/*
let b = 2;
b = 55;
// sehr viele Zeilen
let b = 6;
console.log(b);
*/


/**
 * Das ist eine wichtige Begrüßung
*/
//wegen ** ist ein Hinweis, das soll sich 
//der Editor genauer anschauen soll
const message = "Guten Morgen";
//message = "Guten Tag";
console.log(message);
//Wert einer Konstante kann man nicht ändern
//Konstante ohne Wert darf nicht erstellt werden
//++++++++++++++++++++++++++++++++++++++++++++++++++++
let shoppingList  = "     Saft, Banane, Mango, Tomaten, ****Nudeln, Birne, Eis     ";

//Anzahl der Zeichen innerhalb der Einkaufsliste anzeigen.
console.log(shoppingList.length);

//Entferne die Leerzeichen links und rechts.
//Schreibe das Ergebnis zurück in die Variable „shoppingList„ 
//Anzahl der Zeichen innerhalb der Einkaufsliste anzeigen.
shoppingList = shoppingList.trim();
console.log(shoppingList);
console.log(shoppingList.length);

//Finde die Position der vier Stern-Zeichen und speichere diese in einer Variable.
//Schneide die 4 Stern-Zeichen aus und gebe das Ergebnis mit console.log aus.
//Es soll ausgegeben werden: „Saft, Banane, Mango, Tomaten, Nudeln, Birne, Eis“ 
let pos = shoppingList.indexOf("****");
console.log(pos);

console.log(shoppingList.substr(0, pos) + shoppingList.substr(pos+4));
//Verwende dazu einmal die .substr()-Funktion, und einmal die .slide()-Funktion.


//Schneide die 4 Stern-Zeichen aus und gebe das Ergebnis mit console.log aus.
//Verwende dazu die .replace()-Funktion.
console.log(shoppingList.replace("****","") );

//Gebe den Inhalt als Großbuchstaben aus.
console.log(shoppingList.replace("****","").toUpperCase());

//Gebe den Inhalt als Kleinbuchstaben aus.
console.log(shoppingList.replace("****","").toLowerCase());

//Verwende die .replace()-Funktion.
//Bindestrich soll 50 mal ausgegeben werden.
//Inhalt ausgaben
console.log("-".repeat(50));
console.log(shoppingList.replace("****","") );
console.log("-".repeat(50));

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Mathematische Operationen
console.log("#".repeat(40));

//Addition
console.log(5 + 6);

console.log("5 + 6 : " + 5 + 6);

console.log("5 + 6 : " , 5 + 6);

console.log("5 + 6 : " + (5 + 6));

//Subtraktion
console.log(" 6 - 5 : ", 6 - 5);

//Multiplikation
console.log(" 6 x 5 : ", 6 * 5);

//Division
console.log(" 6 / 3 : ", 6 / 3);

//Modulo (Restwert)
console.log(" 11 % 6 : ", 11 % 6);

//Potenz
console.log("2 hoch 10: ", 2 ** 10);

console.log("#".repeat(50) );

//++++++++++++++++++++++++++++++++++++++++++++++++
//Runden
console.log( "Runden, Math.round(5.5)" , Math.round(5.5) );
console.log( "Abrunden, Math.floor(5.5)" , Math.floor(5.5) );
console.log( "Aufrunden, Math.ceil(5.5)" , Math.ceil(5.2) );

//Maximum
console.log("Math.max(1, 2, 5) : ", Math.max(1, 2, 5) );

//Minimum
console.log("Math.min(1, 2, 5) : ", Math.min(1, 2, 5) );

//++++++++++++++++++++++++++++++++++++++++++++++++
let zahl = "3.141";


//          "Hallo" * "Anna"
console.log(zahl * zahl);
//          "3.141" + "3.141"
console.log(zahl + zahl);

//String in eine Ganzzahl umwandeln
//parseInt()

console.log( parseInt(zahl) + parseInt(zahl) );
//lieber manuel schreiben, dass wir zehner Zahlensystem benutzen
console.log(parseInt(zahl, 10));

console.log(typeof zahl);
console.log(typeof parseFloat(zahl) );
//String in eine Kommazahl umwandeln
//hier braucht man keinen 2 Parameter
//++++++++++++++++++++++++++++++++++++++++++++++++
//Achtung beim Rechnen mit Kommazahlen
//Rundungsfehler
//let erg = 20.35 % 6;
let erg = 20.35 % 6 - 2.35;

console.log(erg);

//Lösung: Kommazahlen vermeiden
//let erg2 = 2035 % 600

/*
wichtig in der Praxis, wenn alles bis auf cent
stimmen sollte (Kommazahlen vermeiden)
*/
let erg2 = 2035 % 600 - 235;
console.log(erg2);
//++++++++++++++++++++++++++++++++++++++++++++++++
//Zahl zu String
let zahl3 = 3.14123232323232;
console.log("" + zahl3);

console.log(typeof  zahl3);
console.log(typeof ("" + zahl3) );

//2 Nachkommastellen
console.log(zahl3.toFixed(4));
//++++++++++++++++++++++++++++++++++++++++++++++++
let zeichen1 = "3" == 3;

console.log(zeichen1);

let zeichen2 = "3" === 3;

console.log(zeichen2);
//++++++++++++++++++++++++++++++++++++++++++++++++
//Variablen, die true oder false haben
/*
let a = true
let b = false 
*/
let zeichen3 = "Hallo Hugo" === "Hallo Hugo";
console.log(zeichen3);

let zeichen4 = "Hallo Hugo" === "Hallo hugo";
console.log(zeichen4);

let zeichen5 = "Hallo Hugo" !== "Hallo hugo";
console.log(zeichen5);

let number1 = 6;
let number2 = 8;

console.log("6 === 8", number1 === number2);
console.log("6 !== 8", number1 !== number2);
console.log("6 < 8", number1 < number2);
console.log("6 <= 8", number1 <= number2);
console.log("6 > 8", number1 > number2);
console.log("6 >= 8", number1 >= number2);
/* 
= einer Variable einen Wert zuweisen
=== Vergleiche durchführen
*/
//++++++++++++++++++++++++++++++++++++++++++++++++
/*
if(Bedingung) {
  Anweisung;
} else {
  Anweisungen;
}
*/ 

let zahl1 = 28;
let zahl2 = 22;

if(zahl1 <= zahl2) 
{
  console.log("Zahl1 ist kleiner als Zahl2");
} 
else 
{
  console.log("Zahl1 ist größer als Zahl2");
}
//++++++++++++++++++++++++++++++++++++++++++++++++
let tnZahl = 9;

if(tnZahl < 5) 
{
  console.log("Es sind noch sehr viele Plätze frei");
} 
else 
{
    if(tnZahl < 8)
    {
      console.log("Es sind noch wenige Plätze");
    }
    else
    {
        if(tnZahl < 10)
        {
          console.log("Es sind kaum Plätze frei");
        }
        else
        {
          console.log("Wir sind ausgebucht");
        }
    }
}
//++++++++++++++++++++++++++++++++++++++++++++++++
if(tnZahl < 5) {
  console.log("Es sind noch sehr viele Plätze frei")
}
else if(tnZahl < 8) {
  console.log("Es sind noch wenige Plätze");
}
else if(tnZahl < 10) {
  console.log("Es sind kaum Plätze frei");
}
else
{
  console.log("Wir sind ausgebucht");
}
//++++++++++++++++++++++++++++++++++++++++++++++++
console.log("#".repeat(50) );

//for - Schleife
/*
for(Initialisierung; Bedingung; Aktualisierung) {
  Anweisungen;
}
*/
for(let counter = 1; counter <= 5; counter++) {
  console.log(counter);
  //console.log("Zeile ", counter, ":");
}
//----------------------
//Mensch        1     2       3       4       5       6       7
let liste = ["Andi","Paul","Hugo","Angela","Helene","Boss","Mann","Bohlen"];
//PC            0     1       2       3       4       5       6       7

/* 
Zeile 1: Andi
Zeile 2: Paul
......
Zeile 7: Mann

console.log("Zeile ", 0 , ":" , liste[0] );
console.log("Zeile ", 1 , ":" , liste[1] );
  ......
console.log("Zeile ", 4 , ":" , liste[4] );
*/
console.log(liste);

for(let grace = 0; grace < liste.length; grace++) {
  console.log("Zeile ", (grace+1), ": " , liste[grace])
}
/*
                          <=   (8-1) => weil nur bis [7] existiert
for(let grace = 0; grace <= liste.length-1; grace++) {
  console.log("Zeile ", (grace+1), ": " , liste[grace])
}


                         <   8 => 7 
for(let grace = 0; grace < liste.length; grace++) {
  console.log("Zeile ", (grace+1), ": " , liste[grace])
}
*/
//++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*
while(bedingung) {
  Anweisung;
}
*/

let counter = 0; 

while(counter < 5) {
  counter++;
  console.log("Counter mit while: ", counter);
}