"use strict";

/*
DOM
in konsole schreiben

document.title = 'Hallo Welt'

document.location

document.location.hash


//das document-object Module
console.log(document)

//Titel der Seite
console.log(document.title)

//Titel der Seite ändern
console.log(document.title='Halli Hallo')

hash 	String für einen Anker, der mit einem Hash-Zeichen beginnt
let anker = window.location.hash;

index.html#box3
<a href="#box3">Info</a>

//aktive url, die im Browser steht
href	String mit der vollständigen URL
console.log(document.location.href)
*/

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Elemente finden
//Eigenschaften des Elementen sehen 

//console.log(document.getElementById("datum"));

/*
console.log("Inhalt des Elements: \n" + 
            document.getElementById("datum").innerText    );
*/

//document.getElementById("datum").innerText = "28.12.2021";

let datum = document.getElementById("datum");

//HTML-Element wird escaped als Text dargestellt
//datum.innerText = "<em onclick=\"alert('Hallo')\">30.08.2021</em>";

//HTML-Element wird nicht escaped (verwenden, wenn man vertrauen zur rechten Seite hat)
//datum.innerHTML = "<em onclick=\"alert('Hallo')\">30.08.2021</em>";

//warum innerText bervorzugen?

//SicherheitsRisiko
//console.log(datum.innerHTML = '<em onclick=\'alert("Hallo")\'>30.07.2021</em>')

//bei einem Forum z.B., wo die Daten aus der DB kommen, lieber innerText benutzen
//console.log(datum.innerText = '<em onclick=\'alert("Hallo")\'>30.07.2021</em>')

//++++++++++++++++++++++++++++++++++++++++++++++++++++
//onclick

/*
//Auf Ereignisse reagieren
//onclick lieber nicht verwenden (veraltet)

addEventListener ist eine zentrale Funktion, die Events und die dazugehörigen Aktionen registriert. 
addEventListener behandelt Events für window, document oder individuelle Elemente der Webseite.

-------------------------------
elem.addEventListener(eventType,   // EventType (z.B. click, touch 
                                       o. mouseover)
                      handler,     // aufzurufende Funktion
                      useCapture); // Phase der Aktivierung

removeEventListener löst den Event Handler wieder vom Ereignis.

datum.addEventListener("click", function() {
  alert("Datum wurde angeklickt");
});


datum.addEventListener("click", () => {
  alert("Datum wurde angeklickt");
});



datum.addEventListener("mouseover", () => {
  datum.innerText = "Wir sind im Auftrag des Herrn unterwegs";
});

datum.addEventListener("mouseleave", () => {
  datum.innerText = "Wir sind im Auftrag des Herrn unterwegs";
});
*/
//andere Schreibweise
let klicken = function() {
  alert("Datum wurde angeklickt");
  datum.innerText = "Wir sind im Auftrag des Herrn unterwegs";
}

//klicken();

//wenn so steht dann erst beim klick wird die Funktion ausgeführt
//datum.addEventListener("click", klicken());
//wenn so steht dann wird die Funktion sofort ausgeführt
//Hier wird Ergebnis einer funktion übergeben
//iner Funktion gibts kein Rückgabewert


datum.addEventListener("click", klicken);


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
let mailBtn = document.getElementById("mail");
/*
mailBtn.addEventListener("click", () => {
  alert("Ich bin eine Mail");
})

//blabla übergibt weitere Informationen

mailBtn.addEventListener("click", (blabla) => {
  console.log(blabla);
  alert("Ich bin eine Mail");
});
*/
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//lieber die Variable event nennen
mailBtn.addEventListener("click", (event) => {
  //die normale Aktion unterbinden
	
	//console.log(event)
  //wenn drauf geklickt wird
  //den standardFall verhindern
  //soll nicht zu mailto gehen z.B.
  //Standardfall folgt dem href und das unterbinden wir
  event.preventDefault();
  alert("Ich bin eine Mail");
  //wenn ein user kein JS aktiviert hat dann gehts zum mailto
} );
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
let btnIncrement = document.getElementById("btnHoch");
let btnWeg = document.getElementById("btnReset");
let erg = document.getElementById("wert");

let current = parseInt(erg.innerText);

//man hätte auch so schreiben können
//let current = 0

//<span id="wert">0</span>
btnIncrement.addEventListener("click", () => {
  current++;
  //document.getElementById("wert").innerText = current;
  erg.innerText = current;
});

btnWeg.addEventListener("click", () => {
  current = 0;
  erg.innerText = current;
})
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
let formular = document.getElementById("form");

//formular.onsubmit = function() {}
formular.addEventListener("submit", (event) => {
  //alert("Hallo");
  let name = document.getElementById("nachname").value;
  let vorname = document.getElementById("vorname").value;
  let email = document.getElementById("email").value;
  let msg = document.getElementById("msg");

  if(name.length < 3 || vorname.length < 3) {
    msg.innerHTML = "Name und Vorname müssen mindestens <strong>3</strong> Zeichen haben";
  }
  else if(email.length < 10) {
    msg.innerHTML = "E-Mail muss mindestens <strong>10</strong> Zeichen haben";
  }
  else {
    msg.innerHTML = "Vielen Dank <br />" + name + ", " + vorname + "<br />" + "E-Mail: " +email;
  }
  event.preventDefault();
})
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

formular.addEventListener("reset", (event) => {
  //alert("Du willst die Daten löschen");
  if(!window.confirm("Wollen Sie wirklich alle Eingaben löschen?") ) {
      event.preventDefault();
  } else {
    msg.innerText = "";
  }

});

