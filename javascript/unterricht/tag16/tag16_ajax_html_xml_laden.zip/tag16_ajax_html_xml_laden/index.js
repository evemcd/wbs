"use strict";

//++++++++++++++++++++++++++++++++++++++++
let xmlString = '<?xml version="1.0" encoding="UTF-8"?>'+
                '<artists>'+
                  '<artist name="Georg Michael">'+
                    '<album>'+
                      '<titel>Faith</titel>'+
                      '<jahr>1988</jahr>'+
                    '</album>'+
                    '<album>'+
                      '<titel>Older</titel>'+
                      '<jahr>1994</jahr>'+
                    '</album>'+
                  '</artist>'+
                '</artists>';
/*
//Mit Hilfe des Objects DOMParser lassen sich die Zeichenketten in XML-Objekte umwandeln.
//vorausgesetzt, die übergebene Zeichenkette enthält ein gültiges XML

let xmlDaten = new DOMParser();               
let xmlDom = xmlDaten.parseFromString(xmlString, "text/xml");
console.log(xmlDom.querySelector("artist").getAttribute("name"))

console.log(xmlDom.querySelector("artist").querySelector("titel"));
console.log(xmlDom.querySelector("artist").querySelector("titel").textContent);

console.log(xmlDom.querySelector("artist").querySelectorAll("album"));

let alle = xmlDom.querySelector("artist").querySelectorAll("album");

for(let element of alle) {
  console.log("Name: "+element.querySelector("titel").textContent+
              "\nJahr: "+element.querySelector("jahr").textContent);
}


//XML in Zeichenkette umwandeln
//diesen Prozess nennt man Serialisieren
//das HelferObekt, das zum Einsatz kommt, ist das Object XMLSerializer
//Dieses Objekt stellt die Methode serializeToString() zur Verfügung

let xmlDaten = new DOMParser();
let xmlDom = xmlDaten.parseFromString(xmlString, "text/xml");
let xmlSerial = new XMLSerializer();
console.log(xmlSerial.serializeToString(xmlDom));
let daten = xmlSerial.serializeToString(xmlDom);
console.log(typeof daten);
*/

//#########################################################
/*
XMLHttpRequest()

die Basis für alle Arten von Ajax-Anfragen ist das Objekt
XMLHttpRequest()
ursprünglich von Microsoft entwickelt.

Der Ablauf einer Ajax-Anfrage unter Verwendung von XMLHttpRequest() ist immer ähnlich

Ablauf einer Anfrage per Ajax:

-Instanz von XMLHttpRequest() erstellen
-Konfigurieren des onload-Events
-starten der HTTP-Anfrage über den Aufruf open()
-Absenden der HTTP-Anfrage über send()
*/

//HTML-Daten per Ajax laden
let request = new XMLHttpRequest();
//onload => wenn die Anfrage erfolgreich ausgeführt wurde und die Antwort bereitsteht
request.addEventListener("load", () => {
    //wenn Ergebnis geladen wurde
    //dann die HTML-Antwort als Zeichenkette
    if(request.status === 200) {
      let daten = request.responseText; //HTML-Antwort als Zeichenkette
      document.getElementById("main").innerHTML = daten;
    }
});
request.open("GET", "info.html", true);
request.send();
//#########################################################
let login = document.getElementById("login");
let register = document.getElementById("register");
//das ist zusätzlich, muss man nicht machen
let weg = document.getElementById("weg");

//-----------------------------

weg.addEventListener("click", (event) => {
  event.preventDefault();
  document.getElementById("form").innerHTML = "";
});

function seiteLaden(seitenName) {
  let request = new XMLHttpRequest();
  request.addEventListener("load", () => {
    if(request.status === 200) {
      let daten = request.responseText;
      document.getElementById("form").innerHTML = daten;
    }
  });
	/*
	responseType => über die Eigenschaft kann bestimmt werden,
					welchen Datentyp die Antwort haben soll.
					leere Zeichenkette (String)
					text(String)
					blob (Blob)
					document (Document)
          ....
  setRequestHeader() => setzt den Wert für den angegebenen Header
  Konfiguration der Anfrage
*/
  request.open("GET",seitenName+".html",true);
  request.responseType = "";
  request.setRequestHeader("Accept", "text/html");
  request.send();
}
//ende seiteLaden
//-----------------------------
login.addEventListener("click", (event) => {
  event.preventDefault();
  seiteLaden("login");
});

register.addEventListener("click", (event) => {
  event.preventDefault();
  seiteLaden("register");
});
//#########################################################
let request2 = new XMLHttpRequest();
let ausgabe = "";
request2.addEventListener("load", () => {
    if(request2.status === 200) {
      let daten = request2.responseXML;

      let artists = daten.getElementsByTagName("artist");
     
      for(let i=0; i < artists.length; i++) {
          let albums = artists[i].getElementsByTagName("album");
          ausgabe +="<ul class='list-group d-table my-2'>";
          ausgabe +="<li class='list-group-item fw-bold'>"+artists[i].getAttribute("name")+"</li>";
          ausgabe +="<li class='list-group-item bg-danger text-light'>Album und Erscheinungsjahr</li>";
          for(let j=0; j < albums.length; j++) {
            ausgabe += "<li class='list-group-item'>"+
              albums[j].getElementsByTagName("titel")[0].childNodes[0].nodeValue+
              " ( " + albums[j].getElementsByTagName("jahr")[0].childNodes[0].nodeValue+ " ) " + 
            "</li>";
          }
          ausgabe +="</ul>";
      }
      //ende for
    }
    //ende if
    document.getElementById("xmlDaten").innerHTML = ausgabe;
});

request2.open("GET","album.xml",true);
request2.responseType = "document";
request2.setRequestHeader("Accept", "text/xml");
request2.send();

/*
Inhalte einer Webseite dynamisch nachladen.
Ajax -> Asynchronous JavaScript and XML.
Erstmal 2005 tauchte der Begriff auf (Jesse James Garett)
Die Idee:
Über JS im Hintergrund, Daten mit dem Server austauschen, ohne dass die Webseite komplett neugeladen wird.

++++++++++++++++++++++++++++++++
Synchrone Kommunikation
Client(Browser) ------Eine Anfrage an------> Server

								Warten
(in der Wartezeit können keine weiteren Anfragen getätigt werden)	
							
Server ------die Antwort an------> Browser
++++++++++++++++++++++++++++++++
Asynchrone Kommunikation
Client(Browser) ------Anfrage1---Anfrage2------> Server

Server --Antwort1------> Browser
Server -------Antwort2------> Browser
Server ----------------Antwort3------> Browser
++++++++++++++++++++++++++++++++
Typische Verwendung von Ajax

Automatische Vervollständigung von Eingabefeldern
Paginierung von großen Datensätzen
Newsticker
Editierbare UI-Komponenten
++++++++++++++++++++++++++++++++
Verwendete Dateiformate

HTML
XML
	Eignet sich, wenn die Daten strukturiert vom Server geladen werden sollen.
JSON
	Format genauso wie XML, ist aber um einiges schlanker

Der Begriff "Asynchronous JavaScript and XML" ist irreführend, weil
nicht nur XML als Austauschformat benutzt werden kann.
*/