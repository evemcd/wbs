"use strict";

//Array (ohne Array würde man viele Variablen anlegen)
/*
let student1 = "Angela Merkel";
let student2 = "Helene Fischer";
let student3 = "Thomas Merkel";

Mensch                1                   2                3              4               5
let students = [ "Angela Merkel", "Helene Fischer", "Thomas Merkel","David Sedaris", "Thomas Mann"];
Prog.                 0                   1                 2             3               4
mit einem Array können wir alle Teilnehmer komplett in einer Liste rein tun
*/

let students = [
  "Angela Merkel", 
  "Helene Fischer", 
  "Thomas Merkel",
  "David Sedaris",
  "Thomas Mann"
];

//alles ausgaben
console.log(students);

//was ist der Typ von eimem Array
console.log(typeof students);

console.log(students instanceof Array);

//Wie viele Elemente sind in einem Array
console.log("Anzahl der Elemente: " + students.length);

//Einzelnes Element anzeigen
console.log("[0] " + students[0] );

//Das letzte Element anzeigen
//                                              5 - 1 = 4
console.log("[letztes Element] " + students[students.length - 1] );

//Wenn ein Element nicht existiert, wird "undefined" zurückgegeben
console.log( students[230] );

//Element hinzufügen (am Ende)
students.push("Student1","Student2");
console.log( students );

//Letztes Element entfernen
/*
students.pop();
console.log( students );
*/

//Meldung ausgeben, welches Element gelöscht wurde
let last = students.pop();
console.log("Das letzte Element  \""+ last +"\" wurde gelöscht");
console.log( students );

//Ein Element überschreiben
students[0] = "Dieter Bohlen";
console.log( students );
//++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Veränderliche und unveränderliche Variablen
//Strings sind immutale (unveränderlich)
let greeting = "Hallo Welt";
//Es wird immer eine Kopie erstellt und Original wird nicht verändert
//bzw. dann von JS gelöscht
greeting = "Moin";
console.log(greeting);

console.log(greeting[0]);
/*
bekommt man eine Fehlermeldung weil nicht veränderbar
greeting[0] = "h";
*/

//Array sind veränderlich
//++++++++++++++++++++++++++++++++++++++++++++++++++++++
//der Pfeil auf Array verändert sich nicht
//NUR die Elemente
const std2 = ["Max","Hans"];
//unten geht, aber sollte man nicht machen weil die Konstante sollte unverändert stehen
std2.push("Tom");
console.log(std2);
//neue Elemente hinzufügen usw. ist ok
//aber die ganze Struktur verändern nicht erlaubt
//std2 = ["Max","Hans"];
//++++++++++++++++++++++++++++++++++++++++++++++++++++++
let studentsList = ["Max Müller","Paul Mustermann","Anna Wagner","Max Müller","Tom Moritz"]
console.log("*".repeat(50) );
console.log(studentsList);

//Ist ein Element im Array vorhanden? (wenn das erste Element gefunden wird, bleibt stehen)
console.log( studentsList.indexOf("Max Müller") );

//Ist ein Element im Array vorhanden? (ab einer bestimmten Position)
console.log( studentsList.indexOf("Max Müller", 1) );

//wenn ein Element nicht existiert -> -1
console.log( studentsList.indexOf("Max Fischer") );

console.log("*".repeat(50) );
//++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Array sortieren
// studentsList.sort();
// console.log(studentsList);

//Array - Sortierung umdrehen
// studentsList.reverse();
// console.log(studentsList);

console.log("*".repeat(50) );
//++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Elemente entfernen mit .splice(wo? , wieviele?)
//Danach werden die Indexe neu vergeben
studentsList.splice(0,3);
console.log(studentsList);

//Elemente hinzufügen mit splice(Position, keine Elemente löschen(0), das Element)
//studentsList.splice(0,0,"Joker");
//studentsList.splice(1,0,"Joker");
studentsList.splice(2,0,"Joker1","Joker2")
console.log(studentsList);

console.log("*".repeat(50) );

//++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Es gibt keine Einschränkungen, was in der Liste gepackt wird
// let liste = ["Apfel", 4];
// console.log( liste[0].toUpperCase() );
// console.log( liste[1].toFixed(2) );

//              0     1  2
let liste = ["Apfel", 4, ["Wert1", "Wert2"] ];

console.log(liste);

console.log(liste[2]);

console.log(liste[2][0]);

// 0 1 2 3 4
// W e r t 2
console.log(liste[2][1][2]);

console.log("*".repeat(50) );

//++++++++++++++++++++++++++++++++++++++++++++++++++++++
//String zu Array
//.split() teilt ein String in Array von String auf
let korb1 = "Apfel, Banane, Mango, Birne";

console.log(korb1);

//console.log( korb1.split() );
//console.log( korb1.split("") );
console.log( korb1.split(", ") );

//Array zu String
let korb2 = [ "Apfel", "Banane", "Mango", "Birne" ];

console.log(korb2.join(" - ") );

console.log("*".repeat(50) );

//++++++++++++++++++++++++++++++++++++++++++++++++++++++
//if-Bedeutung

//let abfrage = "Hallo";
let abfrage = "";

//wenn die Variable keinen Wert hat, dann ist false
//if(anfrage) -> bedeutet -> wenn true dann gib was aus (VariablenTypUmwandlung)
if(abfrage) {
  console.log("Hallo Welt");
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Vergleich
// true == 1 (1 wird zu einem true)
//diese Schreibweise kann oft zu problemen führen
//weil nicht streng und automatische Typumwandlung
console.log("true == 1", true == 1);
console.log("true != 1", true != 1);

//Streng: wenn links ein true steht dann rechts muss auch ein true stehen
console.log("true === 1", true === 1);
console.log("true !== 1", true !== 1);

// links steht String und rechts boolean und trotzdem true
console.log("0" == false);

//Lieber immer === verwenden
console.log("0" === false);

console.log("*".repeat(50) );
//++++++++++++++++++++++++++++++++++++++++++++++++++++++
//while - Schleife
//wird selten benutzt

let counter1 = 5;
while(counter1 < 5) {
  console.log("Hallo while : " +counter1);
  counter1++;
}
console.log("*".repeat(50) );
//++++++++++++++++++++++++++++++++++++++++++++++++++++++
//wird noch seltener benutzt als while
let counter2 = 5;
do {
  console.log("Halllo do while : " + counter2);
  counter2++;
}while(counter2 < 5);
console.log("*".repeat(50) );
//++++++++++++++++++++++++++++++++++++++++++++++++++++++
//for-Schleife

for(let counter = 0; counter < 5; counter++) {
  console.log(counter);
}

console.log("*".repeat(50) );
/*
counter = 0
counter = counter + 1
0
0 + 1 = 1
1 + 1 = 2
2 + 1 = 3
3 + 1 = 4
*/ 
for(let counter = 0; counter < 5; counter = counter + 1) {
  console.log(counter);
}

console.log("*".repeat(50) );

for(let counter = 0; counter <= 10; counter = counter + 2) {
  console.log(counter);
}

console.log("*".repeat(50) );

for(let counter = 0; counter <= 10; counter++) {
  counter = counter + 2;
  console.log(counter);
}

console.log("*".repeat(50) );

for(let counter = 0; counter <= 10; counter++) {
  console.log(counter);
}
console.log("*".repeat(50) );
//++++++++++++++++++++++++++++++++++++++++++++++++++++++

//Schleifen abbrechen bzw. überspringen
// continue-Befehl, egal wo er steht, sorgt dafür, dass der aktuelle
// Schleifendurchlauf übersprüngen wird
// das würde man nicht so schreiben
// aber im Zusammenhang mit einer Abfrage
// 
/*
for(let i = 0; i <= 10; i++) {
  continue;
  console.log("Wir sind im Auftrag des Herrn unterwegs " + i);
}
*/

for(let i = 0; i <= 10; i++) {
  //hier wird der 7. Schleifendurchlauf übersprüngen
  //manchmal gibts vielleicht keinen 7 Stock oder 13. Stock:-)
  if(i === 7) {
    continue;
  }

  //mit break kann man die gesamte Schleife abbrechen
  if(i === 9) {
    break;
  }
  console.log("Wir sind im Auftrag des Herrn unterwegs " + i);
}

console.log("*".repeat(50) );
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
let note = 1;

if(note === 1) {
  console.log("Der Teilnehmer ist sehr gut!");
}
else if(note === 2) {
  console.log("Der Teilnehmer ist gut!");
}
else if(note === 3) {
  console.log("Der Teilnehmer ist normal!");
}
else if(note === 4) {
  console.log("Der Teilnehmer ist ok!");
}
else if(note === 5) {
  console.log("Der Teilnehmer ist geht so!");
}
else if(note === 6) {
  console.log("Der Teilnehmer muss viel tun!");
}
else {
  console.log("Der Teilnehmer war stets bemüht!");
}

console.log("*".repeat(50) );
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*
switch Anweisung wertet einen Ausdruck aus
switch case  =>  anstelle mehrfacher if  else-Abfragen 
switch-Anweisung meistens einfacher und effizienter in der Handhabung 

  switch(Ausdruck) {
    case Wert: Anweisung; break;
    case Wert: Anweisung; break;
    case Wert: Anweisung; break;
    defaultWert: Anweisung; break;
  }
*/

let note2 = 10;
switch(note2) {
  case 1: console.log("Der Teilnehmer ist sehr gut!"); break;
  case 2: console.log("Der Teilnehmer ist gut!"); break;
  case 3: console.log("Der Teilnehmer ist normal!"); break;
  case 4: console.log("Der Teilnehmer ist ok!"); break;
  case 5: console.log("Der Teilnehmer ist geht so!"); break;
  case 6: console.log("Der Teilnehmer muss viel tun!"); break;
  default: console.log("Der Teilnehmer war stets bemüht!"); break;
}

let note3 = 4;
switch(note3) {
  case 1:
  case 2: 
  case 3: console.log("Ein braver Teilnehmer!"); break;
  case 4: console.log("Der Teilnehmer ist ok!"); break;
  case 5: console.log("Der Teilnehmer ist geht so!"); break;
  case 6: console.log("Der Teilnehmer muss viel tun!"); break;
  default: console.log("Der Teilnehmer war stets bemüht!"); break;
}
console.log("*".repeat(50) );
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Operatoren: && und ||

let gesamtPreis = 20;
let menge = 4;

if(gesamtPreis >= 22 || menge >= 3) {
  console.log("Du bekommst einen Gutschein für den nächsten Einkauf");
}
else {
  console.log("Vielen Dank für ihren Einkauf");
}

console.log("*".repeat(50) );

if(gesamtPreis >= 22 && menge >= 3) {
  console.log("Du bekommst einen 20% Rabatt");
}
else {
  console.log("Vielen Dank");
}
console.log("*".repeat(50) );
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
let liste1 = ["Max","Moritz","Hans","Angela","Helene"];

console.log("++++++++++++++++Ausgabe mit for+++++++++++++++++");
for(let i = 0; i < liste1.length; i++) {
  console.log("- " + liste1[i] );
}

console.log("++++++++++++++++Ausgabe mit while+++++++++++++++++");
let zaehler = 0;
while(zaehler < liste.length) {
  console.log("- " + liste1[zaehler] );
  zaehler++;
}
console.log("*".repeat(50) );
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*
for(Variable of wasMussIchDurchlaufen(wo?)) {
  Anweisungen
}

let liste = ["Max","Moritz","Hans","Angela","Helene"];

Bei jedem Durchlauf wird variable der jeweils gefundene Wert zugewiesen.

Mit dem for...of statement können sogenannte iterable objects durchlaufen werden
(Array)
*/
console.log("++++++++++++++++Ausgabe mit for of+++++++++++++++++");
for(let element of liste1) {
  console.log("- " + element);
}

console.log("++++++++++++++++Ausgabe mit for in+++++++++++++++++");
//Lieber für Objekte benutzen
//Bei Objekten durchläuft for in alle Eigenschaften eines Objekts.
for(let element in liste1) {
  console.log(element);
}