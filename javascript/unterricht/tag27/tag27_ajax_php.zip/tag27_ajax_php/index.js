"use strict";

//####################################################
jQuery(document).ready(function(){

function animation() {
  $("#navi1 ul li a").fadeTo(3000, 0.04).fadeTo(2000, 1);

  setTimeout(animation, 5000);
}

animation();
//****************************************************
//ajax und php
$.get({
  url: "daten.php",
  dataType: "text"
})
.done(function(data) {
  //console.log(data);

  $("#phpDaten").html(data);

  let value = "";
  //-----------------
  $("#user").change(function() {
    //alert("change funktioniert");
    //$("#userDaten").html( $(this).val() );

    //auf den Wert vom select(option->value) zugreifen
		//den Wert vom select in einer Variable rein tun
    value = $(this).val();
    //$("#userDaten").html( value );
    if(value === "") {
      //$("#userDaten").text("Bitte einen User auswählen");
      $("#userDaten").text("");
    }else {
        //++++++++++++++
        $.get({
          //geh zur profil.php und hinterher wird der Wert vom select geschickt
          url: "profil.php?id="+value,
          dataType: "text"
        }).done(function(data){
          $("#userDaten").html(data);
        }).fail(function() {
          $("#userDaten").text("Datei profil.php nicht gefunden");
        });
        //++++++++++++++
    }//ende else

  }); //ende change
  //-----------------
})//ende done
.fail(function() {
  $("#userDaten").text("Datei daten.php nicht gefunden");
});




});
//ende ready()

