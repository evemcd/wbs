<?php 

$db = new PDO('mysql:host=localhost;dbname=myblog_webdev10','root','');
$db->query('SET NAMES utf8');

//erstmal alle User anzeigen, sortiert nach Namen
$sql = 'SELECT * FROM users ORDER BY name';
$st = $db->query($sql);
$daten = $st->fetchAll();
?>

<h2>User-Datenbank</h2>
<form class="col-md-4">
<select name="user" id="user" class="form-select">
  <option value="">Bitte auswählen</option>
  <?php 
  /*
    foreach($daten AS $werte) {
      echo '<option>'.$werte['name'].'</option>';
    }
    */
  ?>
  <?php foreach($daten AS $werte): ?>
    <option value="<?= $werte['id'] ?>">
      <?= $werte['name'] ?>
    </option>
  <?php endforeach; ?>
  <!-- den Wert von value brauchen wir in der Abfrage (profil.php) -->
</select>
</form>




